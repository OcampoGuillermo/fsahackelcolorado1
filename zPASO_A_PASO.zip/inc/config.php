<?php
/**
 * Configuración local (NO subir a GitHub — ver .gitignore).
 * XAMPP por defecto: host 127.0.0.1, usuario root, sin contraseña.
 */

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'formosahack');
define('DB_USER', 'root');
define('DB_PASS', '');

define('APP_NAME', 'CaszaMosqui');
define('APP_TAGLINE', 'Vigilancia comunitaria contra los criaderos de mosquitos');
define('APP_VERSION', '1.0.0');

define('BASE_URL', '/formosahack-2026');